/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.calculadorabasica.estefanyalbizurez;

/**
 *
 * @author LABORATORIO
 */
public class CalculadoraBasica3EstefanyAlbizurez {

    public static void main(String[] args) {
       jfrmCalc holaPos= new jfrmCalc();
       holaPos.setVisible(true);
    }
}
