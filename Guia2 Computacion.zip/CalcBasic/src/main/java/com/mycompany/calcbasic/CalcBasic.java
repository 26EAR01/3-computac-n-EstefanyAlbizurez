/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.calcbasic;

/**
 *
 * @author albiz
 */
public class CalcBasic {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
